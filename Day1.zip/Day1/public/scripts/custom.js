var Hello=React.createClass({
		render:function(){
			return(
				<h1>Hello Wrold</h1>
				)
		}

		
	})
	ReactDOM.render(<Hello/>,
			document.getElementById("container")
			)